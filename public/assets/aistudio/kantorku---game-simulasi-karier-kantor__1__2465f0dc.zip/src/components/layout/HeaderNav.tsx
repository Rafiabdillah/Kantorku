import React, { useState } from 'react';
import { useGameStore, AppView } from '../../store/useGameStore';
import { CharacterAvatar } from '../character/CharacterAvatar';
import { TIERS, TierLevel } from '../../types';
import { sound } from '../../services/sound';
import {
  Briefcase,
  Flame,
  Coins,
  Volume2,
  VolumeX,
  Menu,
  X,
  Compass,
  Map,
  BookOpen,
  Trophy,
  ShoppingBag,
  Settings,
  Sparkles,
  FileCheck,
  GraduationCap,
} from 'lucide-react';
import { PWAInstallButton } from '../pwa/PWAInstallButton';

export const HeaderNav: React.FC = () => {
  const { profile, currentView, setView } = useGameStore();
  const [mobileMenuOpen, setMobileMenuOpen] = useState<boolean>(false);
  const [isMuted, setIsMuted] = useState<boolean>(sound.getMuted());

  const tierInfo = TIERS[profile.currentTier] || TIERS[1];
  const nextTier = profile.currentTier < 7 ? TIERS[(profile.currentTier + 1) as TierLevel] : null;
  const currentTierXp = tierInfo.minXp;
  const nextTierXp = nextTier ? nextTier.minXp : 25000;
  const xpInTier = Math.max(0, profile.xp - currentTierXp);
  const xpNeeded = Math.max(1, nextTierXp - currentTierXp);
  const xpPercent = Math.min(100, Math.round((xpInTier / xpNeeded) * 100));

  const navItems: { view: AppView; label: string; icon: React.ReactNode }[] = [
    { view: 'office', label: 'Kantor', icon: <Compass className="w-4 h-4" /> },
    { view: 'learning', label: 'Belajar', icon: <GraduationCap className="w-4 h-4" /> },
    { view: 'career-map', label: 'Peta Karier', icon: <Map className="w-4 h-4" /> },
    { view: 'case-file', label: 'Kasus Nyata', icon: <Briefcase className="w-4 h-4" /> },
    { view: 'portfolio', label: 'Portofolio', icon: <FileCheck className="w-4 h-4" /> },
    { view: 'shop', label: 'Toko', icon: <ShoppingBag className="w-4 h-4" /> },
    { view: 'achievements', label: 'Lencana', icon: <Trophy className="w-4 h-4" /> },
    { view: 'dictionary', label: 'Kamus', icon: <BookOpen className="w-4 h-4" /> },
    { view: 'errors', label: 'Catatan', icon: <Sparkles className="w-4 h-4" /> },
    { view: 'settings', label: 'Pengaturan', icon: <Settings className="w-4 h-4" /> },
  ];

  const handleNavClick = (view: AppView) => {
    setView(view);
    setMobileMenuOpen(false);
  };

  const handleToggleSound = () => {
    const next = sound.toggleMute();
    setIsMuted(next);
  };

  return (
    <header className="sticky top-0 z-40 bg-white/90 backdrop-blur-md border-b border-slate-200/80 px-4 md:px-8 py-2.5">
      <div className="max-w-7xl mx-auto flex items-center justify-between gap-4">
        {/* Brand Lockup */}
        <div
          onClick={() => handleNavClick('office')}
          className="flex items-center gap-2.5 cursor-pointer select-none shrink-0"
        >
          <div className="w-9 h-9 rounded-2xl bg-emerald-600 flex items-center justify-center text-white shadow-md shadow-emerald-600/20">
            <Briefcase className="w-5 h-5" />
          </div>
          <div>
            <div className="font-black text-base tracking-tight text-slate-900 leading-none">
              Kantor<span className="text-emerald-600">Ku</span>
            </div>
            <div className="text-[10px] text-slate-400 font-semibold tracking-wider uppercase mt-0.5">
              PT Maju Sejahtera
            </div>
          </div>
        </div>

        {/* Desktop Nav Items */}
        <nav className="hidden lg:flex items-center gap-1">
          {navItems.map((item) => {
            const isActive = currentView === item.view;
            return (
              <button
                key={item.view}
                type="button"
                onClick={() => handleNavClick(item.view)}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold transition cursor-pointer ${
                  isActive
                    ? 'bg-emerald-50 text-emerald-800 font-bold'
                    : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
                }`}
              >
                {item.icon}
                <span>{item.label}</span>
              </button>
            );
          })}
        </nav>

        {/* Player Status HUD & Wallet */}
        <div className="flex items-center gap-1.5 sm:gap-3 shrink-0">
          {/* XP Progress Capsule */}
          <div className="hidden md:flex flex-col items-end text-right">
            <div className="flex items-center gap-1.5 text-xs font-bold text-slate-800">
              <span className="text-emerald-700">{tierInfo.badge} {tierInfo.title}</span>
              <span className="text-slate-400 text-[10px]">({profile.xp} XP)</span>
            </div>
            <div className="w-24 h-1.5 bg-slate-100 rounded-full overflow-hidden mt-1 border border-slate-200">
              <div
                className="h-full bg-emerald-500 rounded-full transition-all duration-300"
                style={{ width: `${xpPercent}%` }}
              />
            </div>
          </div>

          {/* Coins Badge */}
          <div
            onClick={() => handleNavClick('shop')}
            className="flex items-center gap-1 px-2.5 py-1 bg-amber-50 hover:bg-amber-100/70 border border-amber-200/70 rounded-xl text-amber-900 text-xs font-bold cursor-pointer transition"
            title="Koin Kantor"
          >
            <Coins className="w-3.5 h-3.5 text-amber-600" />
            <span className="font-mono text-[11px]">{profile.coins}</span>
          </div>

          {/* Streak Flame */}
          <div
            onClick={() => handleNavClick('daily')}
            className="flex items-center gap-1 px-2 py-1 bg-rose-50 hover:bg-rose-100/70 border border-rose-200/70 rounded-xl text-rose-900 text-xs font-bold cursor-pointer transition"
            title="Streak Harian"
          >
            <Flame className="w-3.5 h-3.5 text-rose-500 fill-current" />
            <span className="font-mono text-[11px]">{profile.streakDays}</span>
          </div>

          {/* Sound Mute Toggle (Desktop/Tablet) */}
          <button
            type="button"
            onClick={handleToggleSound}
            className="hidden sm:flex p-1.5 hover:bg-slate-100 text-slate-500 rounded-lg transition cursor-pointer"
            title={isMuted ? 'Nyalakan Suara' : 'Matikan Suara'}
          >
            {isMuted ? <VolumeX className="w-4 h-4 text-slate-400" /> : <Volume2 className="w-4 h-4 text-emerald-600" />}
          </button>

          {/* Settings Button (Desktop/Tablet) */}
          <button
            type="button"
            onClick={() => handleNavClick('settings')}
            className={`hidden sm:flex p-1.5 rounded-lg transition cursor-pointer ${
              currentView === 'settings'
                ? 'bg-emerald-100 text-emerald-800'
                : 'hover:bg-slate-100 text-slate-500 hover:text-slate-800'
            }`}
            title="Pusat Pengaturan & Profil"
          >
            <Settings className="w-4 h-4" />
          </button>

          {/* PWA Install Button (Desktop & Tablet) */}
          <div className="hidden sm:flex items-center">
            <PWAInstallButton />
          </div>

          {/* Mobile Menu Toggle */}
          <button
            type="button"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="lg:hidden p-1.5 hover:bg-slate-100 text-slate-700 rounded-lg transition cursor-pointer"
            aria-label="Toggle navigation menu"
          >
            {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </div>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div className="lg:hidden pt-3 pb-2 border-t border-slate-100 mt-2 space-y-2 animate-in slide-in-from-top-2">
          {/* Mobile PWA Install */}
          <div className="px-1 flex items-center justify-between bg-slate-50 p-2 rounded-xl">
            <span className="text-xs font-semibold text-slate-700">Aplikasi KantorKu</span>
            <PWAInstallButton />
          </div>
          <div className="grid grid-cols-2 gap-1.5 p-1">
            {navItems.map((item) => (
              <button
                key={item.view}
                type="button"
                onClick={() => handleNavClick(item.view)}
                className={`flex items-center gap-2 p-2.5 rounded-xl text-xs font-semibold transition ${
                  currentView === item.view ? 'bg-emerald-100 text-emerald-900 font-bold' : 'bg-slate-50 text-slate-700'
                }`}
              >
                {item.icon}
                <span>{item.label}</span>
              </button>
            ))}
          </div>
        </div>
      )}
    </header>
  );
};
