import React, { useState, useMemo } from 'react';
import { SheetGrid, CellData } from '../../types';
import { ExcelFormulaEngine, formatCellValue, parseCellAddress, colRowToAddress } from '../../engine/formula';
import { settingsRepo } from '../../features/settings/settingsRepository';
import { Calculator, DollarSign, Percent, Undo2, Hash } from 'lucide-react';

interface SpreadsheetEditorProps {
  grid: SheetGrid;
  onCellChange: (address: string, data: Partial<CellData>) => void;
  readOnly?: boolean;
}

export const SpreadsheetEditor: React.FC<SpreadsheetEditorProps> = ({ grid, onCellChange, readOnly = false }) => {
  const [selectedCell, setSelectedCell] = useState<string>('B2');
  const [isEditing, setIsEditing] = useState<boolean>(false);
  const [editInput, setEditInput] = useState<string>('');

  const engine = useMemo(() => new ExcelFormulaEngine(grid), [grid]);

  const cols = ['A', 'B', 'C', 'D', 'E', 'F', 'G'];
  const rowCount = 12;

  const currentCellData = grid[selectedCell] || { raw: '' };

  const handleSelectCell = (addr: string) => {
    setSelectedCell(addr);
    setIsEditing(false);
    setEditInput(grid[addr]?.raw ?? '');
  };

  const handleCellClick = (addr: string) => {
    handleSelectCell(addr);
  };

  const handleCellDoubleClick = (addr: string) => {
    if (readOnly) return;
    setSelectedCell(addr);
    setIsEditing(true);
    setEditInput(grid[addr]?.raw ?? '');
  };

  const commitEdit = () => {
    setIsEditing(false);
    onCellChange(selectedCell, { raw: editInput });
  };

  const toggleFormat = (format: CellData['format']) => {
    const cur = grid[selectedCell]?.format;
    onCellChange(selectedCell, { format: cur === format ? 'number' : format });
  };

  return (
    <div className="flex flex-col h-full bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden select-none">
      {/* Formula & Formatting Ribbon Bar */}
      <div className="flex items-center gap-2 p-2 px-3 bg-slate-50 border-b border-slate-200 text-xs">
        {/* Quick Format Tools */}
        <div className="flex items-center gap-1 border-r border-slate-200 pr-2">
          <button
            type="button"
            onClick={() => toggleFormat('rupiah')}
            className={`p-1.5 rounded-lg flex items-center gap-1 font-semibold transition ${
              currentCellData.format === 'rupiah' ? 'bg-emerald-100 text-emerald-800' : 'hover:bg-slate-200 text-slate-700'
            }`}
            title="Format Rupiah (Rp)"
          >
            <DollarSign className="w-3.5 h-3.5" />
            <span>Rp</span>
          </button>
          <button
            type="button"
            onClick={() => toggleFormat('percent')}
            className={`p-1.5 rounded-lg flex items-center gap-1 font-semibold transition ${
              currentCellData.format === 'percent' ? 'bg-amber-100 text-amber-800' : 'hover:bg-slate-200 text-slate-700'
            }`}
            title="Format Persen (%)"
          >
            <Percent className="w-3.5 h-3.5" />
          </button>
          <button
            type="button"
            onClick={() => toggleFormat('number')}
            className={`p-1.5 rounded-lg flex items-center gap-1 font-semibold transition ${
              currentCellData.format === 'number' ? 'bg-blue-100 text-blue-800' : 'hover:bg-slate-200 text-slate-700'
            }`}
            title="Format Angka Ribuan"
          >
            <Hash className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* Selected Coordinate Indicator */}
        <div className="w-14 px-2 py-1 bg-white font-mono font-bold text-center border border-slate-300 rounded shadow-inner text-slate-800">
          {selectedCell}
        </div>

        {/* Formula Bar */}
        <div className="flex items-center gap-1.5 flex-1 bg-white px-2.5 py-1 border border-slate-300 rounded focus-within:border-emerald-500 focus-within:ring-1 focus-within:ring-emerald-500">
          <span className="font-serif italic font-bold text-slate-400 select-none">fx</span>
          <input
            type="text"
            className="w-full text-xs font-mono outline-none text-slate-900 placeholder:text-slate-400"
            placeholder="Ketik rumus (misal: =SUM(B2:B4)) atau angka"
            value={grid[selectedCell]?.raw ?? ''}
            disabled={readOnly}
            onChange={(e) => {
              onCellChange(selectedCell, { raw: e.target.value });
            }}
          />
        </div>
      </div>

      {/* Grid Canvas */}
      <div className="flex-1 overflow-auto bg-slate-100">
        <table className="border-collapse table-fixed w-full text-xs" style={{ fontSize: 'var(--cell-font-size, 13pt)' }}>
          <thead>
            <tr className="bg-slate-200 text-slate-600 font-semibold sticky top-0 z-10">
              <th className="w-10 h-7 border-r border-b border-slate-300 text-center bg-slate-200">#</th>
              {cols.map((col) => (
                <th key={col} className="w-32 h-7 border-r border-b border-slate-300 text-center font-mono">
                  {col}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {Array.from({ length: rowCount }).map((_, rIdx) => {
              const rowNum = rIdx + 1;
              return (
                <tr key={rowNum}>
                  <td className="w-10 h-7 border-r border-b border-slate-300 text-center bg-slate-100 font-mono text-slate-500 font-semibold">
                    {rowNum}
                  </td>
                  {cols.map((col) => {
                    const addr = `${col}${rowNum}`;
                    const cell = grid[addr] || { raw: '' };
                    const isSelected = selectedCell === addr;
                    const isHeader = cell.isHeader;

                    // Evaluate cell display value
                    let displayVal: any = cell.raw ?? '';
                    let isError = false;
                    let friendlyError = '';

                    if (String(cell.raw ?? '').startsWith('=')) {
                      const evaluated = engine.evaluateFormula(String(cell.raw).substring(1));
                      displayVal = evaluated.value;
                      if (evaluated.error) {
                        isError = true;
                        friendlyError = evaluated.friendlyError || evaluated.error;
                      }
                    }

                    const formattedDisplay = formatCellValue(displayVal, cell.format);

                    return (
                      <td
                        key={addr}
                        data-cell={addr}
                        onClick={() => handleCellClick(addr)}
                        onDoubleClick={() => handleCellDoubleClick(addr)}
                        title={friendlyError || displayVal}
                        className={`h-7 px-2 border-r border-b border-slate-200 truncate cursor-pointer transition-colors relative ${
                          isHeader
                            ? 'bg-slate-100 font-bold text-slate-800'
                            : isSelected
                            ? 'bg-emerald-50 ring-2 ring-emerald-600 ring-inset z-20'
                            : 'bg-white hover:bg-slate-50 text-slate-800'
                        } ${isError ? 'text-rose-600 font-semibold bg-rose-50' : ''}`}
                      >
                        {isEditing && isSelected ? (
                          <input
                            type="text"
                            autoFocus
                            className="absolute inset-0 px-2 w-full h-full text-xs font-mono bg-white outline-none ring-2 ring-emerald-500 z-30"
                            value={editInput}
                            onChange={(e) => setEditInput(e.target.value)}
                            onBlur={commitEdit}
                            onKeyDown={(e) => {
                              if (e.key === 'Enter') commitEdit();
                              if (e.key === 'Escape') setIsEditing(false);
                            }}
                          />
                        ) : (
                          <div className={`truncate ${typeof displayVal === 'number' ? 'text-right font-mono' : 'text-left'}`}>
                            {formattedDisplay}
                          </div>
                        )}
                      </td>
                    );
                  })}
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {/* Sheet Tab Bar Footer */}
      <div className="flex items-center justify-between px-3 py-1.5 bg-slate-100 border-t border-slate-200 text-xs text-slate-600">
        <div className="flex items-center gap-2">
          <div className="px-3 py-1 bg-white font-semibold text-emerald-700 border-t-2 border-emerald-600 rounded-t shadow-sm">
            Sheet1 (Aktif)
          </div>
          <span className="text-slate-400">|</span>
          <span className="text-[11px] text-slate-500 font-mono">
            Pemisah: {settingsRepo.get('excel_separator', 'semicolon') === 'semicolon' ? 'Titik Koma (;)' : 'Koma (,)'}
          </span>
        </div>
        <div className="text-[11px] text-slate-500">
          {grid[selectedCell]?.raw ? `Isi: ${grid[selectedCell]?.raw}` : 'Sel Kosong'}
        </div>
      </div>
    </div>
  );
};
