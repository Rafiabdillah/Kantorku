import { LevelItem } from '../types';

export const LEVELS: LevelItem[] = [
  // ==========================================
  // --- EXCEL TRACK ---
  // ==========================================
  {
    id: 'excel-t1-01',
    module: 'excel',
    tier: 1,
    chapter: 1,
    order: 1,
    title: 'Input Data & Format Rupiah',
    subtitle: 'Merapikan daftar inventaris kantor PT Maju Sejahtera',
    character: 'dimas',
    story: 'Hari pertamamu di kantor! Dimas memintamu merapikan daftar harga perlengkapan kantor yang baru dibeli.',
    dialogue: [
      {
        speaker: 'dimas',
        text: 'Halo! Selamat datang di tim operasional. Bos Sari minta rekap harga ATK ini diformat rapi dalam Rupiah.',
        expression: 'happy',
        choices: [
          {
            id: 'c1',
            text: 'Siap Dimas, saya rapikan dan format angka ke Rupiah sekarang juga.',
            type: 'communication',
            response: 'Mantap bro, santai aja tapi teliti ya!',
            repGain: 5,
          },
          {
            id: 'c2',
            text: 'Kenapa tidak langsung diformat dari sistem kasir sebelumnya?',
            type: 'priority',
            response: 'Hehe maklum sistem lama ekspornya masih angka mentah.',
            repGain: 2,
          },
        ],
      },
    ],
    conceptBrief: 'Format Rupiah membuat angka moneter mudah dibaca tanpa mengubah nilai numerik aslinya. Di Excel, gunakan format mata uang Currency/Accounting.',
    workedExample: 'Angka "15000" bila diberi format Rupiah akan tampil sebagai "Rp 15.000".',
    objectives: [
      { id: 'obj-1', text: 'Ketik harga Kertas HVS (55000) pada sel B2', completed: false },
      { id: 'obj-2', text: 'Ketik harga Spidol Whiteboard (12000) pada sel B3', completed: false },
      { id: 'obj-3', text: 'Ketik harga Ordner Binder (35000) pada sel B4', completed: false },
    ],
    initialData: {
      excel: {
        A1: { raw: 'Nama Barang', isHeader: true },
        B1: { raw: 'Harga Satuan', isHeader: true },
        A2: { raw: 'Kertas HVS A4' },
        B2: { raw: '', format: 'rupiah' },
        A3: { raw: 'Spidol Whiteboard' },
        B3: { raw: '', format: 'rupiah' },
        A4: { raw: 'Ordner Binder' },
        B4: { raw: '', format: 'rupiah' },
      },
    },
    hints: [
      'Klik sel B2 lalu ketik angka 55000 kemudian tekan Enter.',
      'Lanjutkan mengisi sel B3 dengan 12000 dan B4 dengan 35000.',
      'Pastikan hanya mengetik angkanya saja tanpa mengetik manual tulisan "Rp".',
    ],
    bossHelp: 'Ketik langsung angka murni di sel B2 (55000), B3 (12000), dan B4 (35000). Sistem akan memformatnya ke Rupiah otomatis!',
    referenceSolution: 'B2: 55000, B3: 12000, B4: 35000',
    solutionExplanation: 'Di Excel, masukkan angka polos ke dalam sel, lalu ubah Number Format-nya. Jangan mengetik teks "Rp" manual agar sel tetap dapat dihitung dengan rumus matematika.',
    commonMistakes: [
      'Mengetik "Rp 55.000" secara manual sehingga Excel menganggapnya sebagai teks dan tidak bisa dijumlahkan.',
      'Salah memasukkan angka pada baris barang.',
    ],
    xpReward: 100,
    coinReward: 50,
    estimatedMinutes: 3,
    skillsTaught: ['Data Entry', 'Number Formatting', 'Currency Format'],
  },

  {
    id: 'excel-t1-02',
    module: 'excel',
    tier: 1,
    chapter: 1,
    order: 2,
    title: 'Penjumlahan Total dengan SUM',
    subtitle: 'Menghitung total pengeluaran divisi operasional',
    character: 'sari',
    story: 'Bu Sari datang ke meja kerjamu untuk memeriksa total anggaran belanja ATK.',
    dialogue: [
      {
        speaker: 'sari',
        text: 'Bagaimana rekap ATK tadi? Saya butuh total pengeluarannya sekarang. Gunakan rumus SUM ya, jangan dihitung manual.',
        expression: 'stern',
        choices: [
          {
            id: 'c1',
            text: 'Baik Bu Sari, saya gunakan fungsi =SUM(B2:B4) agar dinamis dan bebas salah hitung.',
            type: 'ethics',
            response: 'Bagus, itu prinsip kerja profesional yang saya harapkan.',
            repGain: 8,
          },
        ],
      },
    ],
    conceptBrief: 'Rumus =SUM(rentang) menjumlahkan seluruh angka dalam rentang sel yang dipilih. Contoh: =SUM(B2:B4) menjumlahkan sel B2, B3, dan B4.',
    workedExample: '=SUM(B2:B4) akan menghasilkan penjumlahan otomatis dari B2 sampai B4.',
    objectives: [
      { id: 'obj-1', text: 'Masukkan rumus =SUM(B2:B4) pada sel B5 untuk menghitung total belanja', completed: false },
    ],
    initialData: {
      excel: {
        A1: { raw: 'Nama Barang', isHeader: true },
        B1: { raw: 'Harga Satuan', isHeader: true },
        A2: { raw: 'Kertas HVS A4' },
        B2: { raw: '55000', format: 'rupiah' },
        A3: { raw: 'Spidol Whiteboard' },
        B3: { raw: '12000', format: 'rupiah' },
        A4: { raw: 'Ordner Binder' },
        B4: { raw: '35000', format: 'rupiah' },
        A5: { raw: 'TOTAL PENGELUARAN', isHeader: true },
        B5: { raw: '', format: 'rupiah' },
      },
    },
    hints: [
      'Klik sel B5 di sebelah tulisan TOTAL PENGELUARAN.',
      'Awali dengan tanda sama dengan: =SUM(B2:B4)',
      'Tekan Enter setelah menulis rumus =SUM(B2:B4). Nilai yang dihasilkan harus Rp 102.000.',
    ],
    bossHelp: 'Ketikkan =SUM(B2:B4) di sel B5. Jangan ketik angka 102000 secara manual karena jika data barang berubah rumusnya harus ikut update!',
    referenceSolution: 'B5: =SUM(B2:B4)',
    solutionExplanation: 'Fungsi SUM(rentang_awal:rentang_akhir) adalah rumus paling fundamental di Excel. Selalu awali rumus dengan tanda "=".',
    commonMistakes: [
      'Menulis 102000 secara manual (hardcoding) tanpa menggunakan rumus.',
      'Lupa menulis tanda sama dengan (=) di awal rumus.',
    ],
    xpReward: 120,
    coinReward: 60,
    estimatedMinutes: 3,
    skillsTaught: ['Formula Basics', 'SUM Function', 'Range Selection'],
  },

  {
    id: 'excel-t2-01',
    module: 'excel',
    tier: 2,
    chapter: 2,
    order: 1,
    title: 'Referensi Mutlak ($) & Perhitungan PPN',
    subtitle: 'Menghitung pajak penjualan tanpa error saat formula ditarik',
    character: 'reza',
    story: 'Pak Reza menguji ketelitianmu: hitung PPN 11% untuk tiap barang menggunakan sel tarif pajak tunggal.',
    dialogue: [
      {
        speaker: 'reza',
        text: 'Tarif PPN ada di sel E1 (11%). Jangan tulis 0.11 di rumus tiap baris! Kunci sel referensinya dengan tanda $.',
        expression: 'stern',
        choices: [
          {
            id: 'c1',
            text: 'Siap Pak Reza! Saya kunci alamatnya dengan $E$1 agar fleksibel bila regulasi PPN berubah sewaktu-waktu.',
            type: 'priority',
            response: 'Tepat sekali. Itu dasar perancangan model keuangan yang tahan uji.',
            repGain: 6,
          },
        ],
      },
    ],
    conceptBrief: 'Tanda dollar ($) mengunci baris dan/atau kolom sehingga alamat sel tidak berubah saat rumus disalin (misal: $E$1).',
    workedExample: '=B2*$E$1. Jika ditarik ke baris 3, rumusnya menjadi =B3*$E$1. Sel E1 tetap terkunci!',
    objectives: [
      { id: 'obj-1', text: 'Hitung PPN sel C2 dengan rumus =B2*$E$1', completed: false },
      { id: 'obj-2', text: 'Hitung PPN sel C3 dengan rumus =B3*$E$1', completed: false },
      { id: 'obj-3', text: 'Hitung PPN sel C4 dengan rumus =B4*$E$1', completed: false },
    ],
    initialData: {
      excel: {
        A1: { raw: 'Produk', isHeader: true },
        B1: { raw: 'Harga Dasar', isHeader: true },
        C1: { raw: 'Nilai PPN', isHeader: true },
        D1: { raw: 'Tarif PPN:', isHeader: true },
        E1: { raw: '0.11', format: 'percent' },
        A2: { raw: 'Printer Laser' },
        B2: { raw: '2000000', format: 'rupiah' },
        C2: { raw: '', format: 'rupiah' },
        A3: { raw: 'Monitor 24 Inch' },
        B3: { raw: '1500000', format: 'rupiah' },
        C3: { raw: '', format: 'rupiah' },
        A4: { raw: 'Keyboard Mekanikal' },
        B4: { raw: '600000', format: 'rupiah' },
        C4: { raw: '', format: 'rupiah' },
      },
    },
    hints: [
      'Ketik rumus =B2*$E$1 di sel C2.',
      'Untuk C3 gunakan =B3*$E$1, dan C4 gunakan =B4*$E$1.',
      'Tanda dollar ($) di depan E dan 1 memastikan sel tarif pajak tetap merujuk ke E1.',
    ],
    bossHelp: 'Isi C2 dengan =B2*$E$1, C3 dengan =B3*$E$1, C4 dengan =B4*$E$1. Hasilnya berturut-turut adalah Rp 220.000, Rp 165.000, dan Rp 66.000.',
    referenceSolution: 'C2: =B2*$E$1, C3: =B3*$E$1, C4: =B4*$E$1',
    solutionExplanation: 'Referensi absolut ($) adalah pembeda utama antara pemula dan staf andal.',
    commonMistakes: [
      'Menulis =B2*E1 tanpa tanda $ sehingga jika ditarik referensinya salah.',
      'Menulis angka 11% langsung di dalam rumus.',
    ],
    xpReward: 200,
    coinReward: 80,
    estimatedMinutes: 4,
    skillsTaught: ['Absolute Reference ($)', 'Tax Calculation', 'Formula Dragging'],
  },

  {
    id: 'excel-t3-01',
    module: 'excel',
    tier: 3,
    chapter: 3,
    order: 1,
    title: 'Logika Keputusan dengan IF & Status Kelulusan',
    subtitle: 'Menentukan status evaluasi masa percobaan staf',
    character: 'maya',
    story: 'Maya dari tim HR meminta bantuanmu menentukan kelulusan masa percobaan karyawan berdasarkan skor ujian.',
    dialogue: [
      {
        speaker: 'maya',
        text: 'Standar kelulusan di PT Maju Sejahtera adalah skor minimal 75. Jika skor >= 75 berikan status "LULUS", jika di bawah itu berikan "REMEDIAL".',
        expression: 'normal',
      },
    ],
    conceptBrief: 'Fungsi IF(tes_logika; nilai_jika_benar; nilai_jika_salah) mengembalikan hasil berbeda berdasarkan kondisi.',
    workedExample: '=IF(B2>=75; "LULUS"; "REMEDIAL") mengecek apakah nilai B2 minimal 75.',
    objectives: [
      { id: 'obj-1', text: 'Tentukan status sel C2 dengan rumus =IF(B2>=75; "LULUS"; "REMEDIAL")', completed: false },
      { id: 'obj-2', text: 'Tentukan status sel C3 dengan rumus =IF(B3>=75; "LULUS"; "REMEDIAL")', completed: false },
      { id: 'obj-3', text: 'Tentukan status sel C4 dengan rumus =IF(B4>=75; "LULUS"; "REMEDIAL")', completed: false },
    ],
    initialData: {
      excel: {
        A1: { raw: 'Nama Peserta', isHeader: true },
        B1: { raw: 'Skor Ujian', isHeader: true },
        C1: { raw: 'Status', isHeader: true },
        A2: { raw: 'Andi Pratama' },
        B2: { raw: '82' },
        C2: { raw: '' },
        A3: { raw: 'Budi Santoso' },
        B3: { raw: '68' },
        C3: { raw: '' },
        A4: { raw: 'Citra Dewi' },
        B4: { raw: '90' },
        C4: { raw: '' },
      },
    },
    hints: [
      'Format rumus IF: =IF(kondisi; "teks_jika_benar"; "teks_jika_salah")',
      'Di sel C2 masukkan: =IF(B2>=75; "LULUS"; "REMEDIAL")',
      'Kamu bisa menggunakan pemisah titik koma (;) atau koma (,).',
    ],
    bossHelp: 'Ketik di C2: =IF(B2>=75; "LULUS"; "REMEDIAL"). Ulangi di C3 (B3>=75) dan C4 (B4>=75). Hasilnya: LULUS, REMEDIAL, LULUS.',
    referenceSolution: 'C2: =IF(B2>=75, "LULUS", "REMEDIAL")',
    solutionExplanation: 'Logika kondisional IF merupakan dasar automasi pengambilan keputusan di spreadsheet bisnis.',
    commonMistakes: [
      'Lupa memberikan tanda kutip ganda (" ") pada teks LULUS atau REMEDIAL sehingga muncul error #NAME?.',
      'Menggunakan tanda > padahal ketentuannya minimal (harus >=).',
    ],
    xpReward: 250,
    coinReward: 100,
    estimatedMinutes: 5,
    skillsTaught: ['Logical IF', 'Conditional Output', 'Comparison Operators'],
  },

  {
    id: 'excel-t4-01',
    module: 'excel',
    tier: 4,
    chapter: 4,
    order: 1,
    title: 'Pencarian Relasional dengan VLOOKUP & XLOOKUP',
    subtitle: 'Mengambil nama divisi & gaji pokok berdasarkan NIK karyawan',
    character: 'hendra',
    story: 'Pak Hendra mengaudit pencocokan data pegawai. Beliau meminta Anda mengambil data Divisi dari tabel master referensi.',
    dialogue: [
      {
        speaker: 'hendra',
        text: 'Tabel transaksi hanya memuat NIK. Ambil Nama Divisi dari tabel master sebelah kanan menggunakan rumus lookup.',
        expression: 'stern',
      },
    ],
    conceptBrief: 'VLOOKUP(nilai_dicari; tabel_referensi; nomor_kolom; [cocok_persis]) mencari data vertikal dari kolom pertama tabel.',
    workedExample: '=VLOOKUP(A2; E2:G5; 2) mencari NIK A2 pada tabel E2:G5 dan mengembalikan kolom ke-2 (Divisi).',
    objectives: [
      { id: 'obj-1', text: 'Ambil Divisi di sel B2 dengan =VLOOKUP(A2; E2:G5; 2)', completed: false },
      { id: 'obj-2', text: 'Ambil Divisi di sel B3 dengan =VLOOKUP(A3; E2:G5; 2)', completed: false },
    ],
    initialData: {
      excel: {
        A1: { raw: 'NIK', isHeader: true },
        B1: { raw: 'Divisi', isHeader: true },
        A2: { raw: '102' },
        B2: { raw: '' },
        A3: { raw: '101' },
        B3: { raw: '' },
        E1: { raw: 'NIK Master', isHeader: true },
        F1: { raw: 'Nama Divisi', isHeader: true },
        G1: { raw: 'Lokasi Kantor', isHeader: true },
        E2: { raw: '101' },
        F2: { raw: 'Finance' },
        G2: { raw: 'Lantai 3' },
        E3: { raw: '102' },
        F3: { raw: 'Marketing' },
        G3: { raw: 'Lantai 2' },
        E4: { raw: '103' },
        F4: { raw: 'Operasional' },
        G4: { raw: 'Lantai 1' },
      },
    },
    hints: [
      'Gunakan =VLOOKUP(A2; E2:G4; 2)',
      'Nilai yang dicari adalah A2, tabelnya E2:G4, dan indeks kolom Divisi adalah 2.',
      'Di sel B3, ubah nilai yang dicari menjadi A3.',
    ],
    bossHelp: 'Masukkan di B2: =VLOOKUP(A2; E2:G4; 2) dan di B3: =VLOOKUP(A3; E2:G4; 2). B2 akan berisi Marketing dan B3 Finance.',
    referenceSolution: 'B2: =VLOOKUP(A2, E2:G4, 2), B3: =VLOOKUP(A3, E2:G4, 2)',
    solutionExplanation: 'Lookup menghubungkan tabel relasional secara otomatis tanpa perlu input manual yang rentan typo.',
    commonMistakes: [
      'Salah memasukkan nomor kolom.',
      'Salah menentukan rentang tabel referensi.',
    ],
    xpReward: 350,
    coinReward: 150,
    estimatedMinutes: 6,
    skillsTaught: ['VLOOKUP', 'Table Relational Lookup', 'Data Integrity'],
  },

  // ==========================================
  // --- TRACK WEB (HTML + CSS) - PRD v2.0 ---
  // ==========================================
  {
    id: 'web-t1-01',
    module: 'web',
    track: 'web',
    tier: 1,
    chapter: 1,
    order: 1,
    title: 'Struktur Halaman Landing Page Perusahaan',
    subtitle: 'Membangun heading, paragraf, dan tombol call to action',
    character: 'intan',
    story: 'Kak Intan menugaskanmu membuat prototipe landing page sederhana untuk profil PT Maju Sejahtera.',
    dialogue: [
      {
        speaker: 'intan',
        text: 'Selamat datang di Track Web! Fondasi web adalah HTML semantik. Buat halaman dengan heading h1, paragraf pengantar, dan tombol hubungi kami.',
        expression: 'happy',
        choices: [
          {
            id: 'c1',
            text: 'Siap Kak Intan, saya susun dengan tag h1, p, dan button berkelas.',
            type: 'communication',
            response: 'Bagus! Perhatikan juga tag semantik pembungkusnya ya.',
            repGain: 5,
          },
        ],
      },
    ],
    conceptBrief: 'Struktur HTML diawali dengan elemen judul (h1-h6), paragraf (p), dan tautan/tombol interaktif (a/button).',
    workedExample: '<h1>Selamat Datang</h1><p>Solusi bisnis terbaik.</p><button>Hubungi Kami</button>',
    objectives: [
      { id: 'obj-1', text: 'Sertakan tag <h1> untuk judul profil perusahaan', completed: false },
      { id: 'obj-2', text: 'Sertakan tag <p> untuk deskripsi singkat visi misi', completed: false },
      { id: 'obj-3', text: 'Sertakan tag <button> untuk aksi tombol kontak', completed: false },
    ],
    initialData: {
      html: `<!-- Lengkapi struktur landing page di bawah -->
<h1>PT Maju Sejahtera</h1>
<p>Mitra terpercaya automasi dan digitalisasi kantor modern di Indonesia.</p>
<button class="btn-cta">Hubungi Kami</button>`,
      css: `body {
  font-family: Arial, sans-serif;
  padding: 24px;
  background-color: #f8fafc;
}
h1 {
  color: #047857;
  font-size: 24px;
}
p {
  color: #475569;
  line-height: 1.6;
}
.btn-cta {
  background-color: #047857;
  color: white;
  padding: 10px 18px;
  border: none;
  border-radius: 8px;
  cursor: pointer;
}`,
    },
    hints: [
      'Pastikan ada tag <h1> di dalam kode HTML.',
      'Tambahkan tag <p> untuk uraian pengantar.',
      'Sertakan elemen <button> sebagai tombol Call To Action.',
    ],
    bossHelp: 'Struktur template sudah memuat h1, p, dan button! Kamu bisa sesuaikan kata-katanya lalu klik tombol Cek.',
    referenceSolution: 'HTML dengan h1, p, dan button',
    solutionExplanation: 'HTML adalah kerangka struktur dokumen web yang mengorganisasi informasi secara hierarkis.',
    commonMistakes: [
      'Lupa menutup tag seperti </button> atau </h1>.',
      'Menulis teks langsung tanpa membungkusnya dalam tag semantik.',
    ],
    xpReward: 120,
    coinReward: 60,
    estimatedMinutes: 4,
    skillsTaught: ['HTML Structure', 'Headings', 'Paragraphs', 'Buttons'],
    webRequirements: {
      requiredTags: ['h1', 'p', 'button'],
    },
  },

  {
    id: 'web-t2-01',
    module: 'web',
    track: 'web',
    tier: 2,
    chapter: 2,
    order: 1,
    title: 'Tata Letak Responsif dengan CSS Flexbox',
    subtitle: 'Menyusun kartu layanan produk secara berdampingan',
    character: 'intan',
    story: 'Klien menginginkan daftar layanan kantor tampil rapi berdampingan di desktop dan fleksibel di layar kecil.',
    dialogue: [
      {
        speaker: 'intan',
        text: 'Gunakan CSS Flexbox ("display: flex") untuk menata kontainer kartu layanan agar sejajar horizontal dan berjarak proporsional.',
        expression: 'proud',
      },
    ],
    conceptBrief: 'Flexbox adalah model tata letak 1 dimensi yang memudahkan perataan dan pembagian ruang antar item dalam kontainer.',
    workedExample: '.card-container { display: flex; gap: 16px; }',
    objectives: [
      { id: 'obj-1', text: 'Terapkan "display: flex" pada kelas kontainer kartu layanan', completed: false },
      { id: 'obj-2', text: 'Sertakan minimal 2 kartu layanan di dalam kontainer', completed: false },
    ],
    initialData: {
      html: `<div class="layanan-container">
  <div class="card">
    <h3>Audit Keuangan</h3>
    <p>Pemeriksaan laporan kas dan rekonsiliasi bank otomatis.</p>
  </div>
  <div class="card">
    <h3>Pelatihan IT</h3>
    <p>Upskilling karyawan dalam pemrograman dan automasi kerja.</p>
  </div>
</div>`,
      css: `.layanan-container {
  display: flex;
  gap: 16px;
  padding: 16px;
}
.card {
  flex: 1;
  background: white;
  border: 1px solid #cbd5e1;
  border-radius: 12px;
  padding: 16px;
  box-shadow: 0 2px 4px rgba(0,0,0,0.05);
}
h3 {
  margin-top: 0;
  color: #1e293b;
}`,
    },
    hints: [
      'Buka tab style.css dan periksa aturan untuk .layanan-container.',
      'Pastikan properti "display: flex" sudah tertulis dengan benar.',
      'Gunakan gap untuk memberikan jarak antar kartu.',
    ],
    bossHelp: 'Di style.css, pastikan .layanan-container memiliki atribut "display: flex; gap: 16px;".',
    referenceSolution: '.layanan-container { display: flex; gap: 16px; }',
    solutionExplanation: 'CSS Flexbox mengeliminasi kebutuhan float atau penataan manual yang rapuh.',
    commonMistakes: [
      'Menulis display flex pada elemen kartu anak, bukan pada elemen kontainer induk.',
      'Typo penulisan "display: flex".',
    ],
    xpReward: 200,
    coinReward: 80,
    estimatedMinutes: 5,
    skillsTaught: ['CSS Flexbox', 'Card Layout', 'Alignment'],
    webRequirements: {
      requireFlexbox: true,
      requiredTags: ['h3', 'p'],
    },
  },

  // ==========================================
  // --- TRACK JAVASCRIPT ---
  // ==========================================
  {
    id: 'code-t1-01',
    module: 'coding',
    track: 'js',
    tier: 1,
    chapter: 1,
    order: 1,
    title: 'Variabel & Salam Kantor Otomatis',
    subtitle: 'Membuat script penyambut tamu resepsionis',
    character: 'intan',
    story: 'Kak Intan menyambutmu di Lab IT PT Maju Sejahtera. Tantangan pertamamu adalah membuat fungsi penyapa tamu kantor.',
    dialogue: [
      {
        speaker: 'intan',
        text: 'Halo! Di kantor modern, automasi dimulai dari kode kecil. Buat fungsi yang menyapa nama tamu kantor.',
        expression: 'happy',
      },
    ],
    conceptBrief: 'Fungsi (function) menerima input bernama parameter dan mengembalikan (return) nilai hasil olahan.',
    workedExample: 'function sapa(nama) { return "Halo, " + nama; }',
    objectives: [
      { id: 'obj-1', text: 'Buat fungsi sapaTamu(nama) yang mengembalikan "Selamat Datang di PT Maju Sejahtera, " + nama', completed: false },
    ],
    initialData: {
      code: `function sapaTamu(nama) {
  // Lengkapi kode ini
  return "";
}
`,
    },
    hints: [
      'Gunakan string concatenation dengan operator + atau template literals \`Selamat Datang di PT Maju Sejahtera, \${nama}\`.',
      'Pastikan ada spasi setelah tanda koma.',
      'Contoh return: return "Selamat Datang di PT Maju Sejahtera, " + nama;',
    ],
    bossHelp: 'Ketik: return "Selamat Datang di PT Maju Sejahtera, " + nama; di dalam kurung kurawal fungsi sapaTamu.',
    referenceSolution: 'function sapaTamu(nama) { return "Selamat Datang di PT Maju Sejahtera, " + nama; }',
    solutionExplanation: 'Parameter fungsi memungkinkan logika yang sama digunakan berulang kali untuk data yang berbeda.',
    commonMistakes: [
      'Lupa kata kunci return sehingga fungsi menghasilkan undefined.',
      'Typo pada nama perusahaan atau spasi.',
    ],
    xpReward: 120,
    coinReward: 60,
    estimatedMinutes: 4,
    skillsTaught: ['Functions', 'Parameters', 'Return Statements', 'String Concatenation'],
    testCases: [
      { input: ['Budi'], expected: 'Selamat Datang di PT Maju Sejahtera, Budi', description: 'Menyapa tamu Budi' },
      { input: ['Siti'], expected: 'Selamat Datang di PT Maju Sejahtera, Siti', description: 'Menyapa tamu Siti', hidden: true },
    ],
  },

  {
    id: 'code-t2-01',
    module: 'coding',
    track: 'js',
    tier: 2,
    chapter: 2,
    order: 1,
    title: 'Kalkulator Potongan & Diskon Member',
    subtitle: 'Menghitung harga akhir setelah potongan diskon',
    character: 'nadia',
    story: 'Nadia dari tim Pemasaran butuh kalkulator diskon untuk promo bulanan di aplikasi kasir.',
    dialogue: [
      {
        speaker: 'nadia',
        text: 'Hai! Tolong buatkan fungsi hitungHargaAkhir(harga, persenDiskon) agar kasir tidak salah hitung promo.',
        expression: 'proud',
      },
    ],
    conceptBrief: 'Operasi aritmatika di pemrograman mengikuti aturan presisi matematika. Tanda kurung memperjelas urutan kalkulasi.',
    workedExample: 'harga - (harga * (persen / 100))',
    objectives: [
      { id: 'obj-1', text: 'Implementasikan fungsi hitungHargaAkhir(harga, persenDiskon)', completed: false },
    ],
    initialData: {
      code: `function hitungHargaAkhir(harga, persenDiskon) {
  // Tulis logika diskon di sini
  
}
`,
    },
    hints: [
      'Hitung potongan: const potongan = harga * (persenDiskon / 100);',
      'Kurangkan harga awal dengan potongan.',
      'Kembalikan nilainya dengan return harga - potongan;',
    ],
    bossHelp: 'function hitungHargaAkhir(harga, persenDiskon) { return harga - (harga * persenDiskon / 100); }',
    referenceSolution: 'function hitungHargaAkhir(harga, persenDiskon) { return harga - (harga * (persenDiskon / 100)); }',
    solutionExplanation: 'Menghitung persentase diskon adalah logika transaksi bisnis paling umum di aplikasi POS dan e-commerce.',
    commonMistakes: [
      'Lupa membagi persenDiskon dengan 100.',
      'Menulis harga * persenDiskon tanpa mengurangkannya dari harga awal.',
    ],
    xpReward: 200,
    coinReward: 80,
    estimatedMinutes: 5,
    skillsTaught: ['Arithmetic Expressions', 'Business Math', 'Clean Code'],
    testCases: [
      { input: [100000, 20], expected: 80000, description: 'Harga 100.000 diskon 20%' },
      { input: [50000, 10], expected: 45000, description: 'Harga 50.000 diskon 10%' },
      { input: [250000, 0], expected: 250000, description: 'Harga 250.000 diskon 0%', hidden: true },
    ],
  },

  // ==============================================================
  // --- TRACK WORD UNTUK BISNIS DAN AKADEMIK (PRD v2.0) ---
  // ==============================================================
  {
    id: 'word-t1-01',
    module: 'word',
    scale: 'mikro',
    docType: 'Surat Undangan & Nota',
    tier: 1,
    chapter: 1,
    order: 1,
    title: 'Surat Undangan Rapat Koordinasi',
    subtitle: 'Memformat surat resmi dengan hierarki judul & penekanan teks',
    character: 'maya',
    story: 'Maya memintamu menyusun surat undangan rapat koordinasi mingguan untuk seluruh kepala divisi.',
    dialogue: [
      {
        speaker: 'maya',
        text: 'Surat resmi kantor harus memiliki Judul Utama (Heading 1), rincian waktu, serta penekanan tebal (Bold) pada tanggal dan tempat.',
        expression: 'normal',
      },
    ],
    conceptBrief: 'Struktur dokumen profesional diawali Judul yang jelas, paragraf pembuka, rincian agenda, dan penutup sopan.',
    workedExample: 'Gunakan tombol H1 untuk Judul Surat, dan tombol B untuk menebalkan tanggal.',
    objectives: [
      { id: 'obj-1', text: 'Pastikan dokumen memiliki Judul Utama (Heading 1)', completed: false },
      { id: 'obj-2', text: 'Cantumkan kata kunci "Undangan", "Rapat", dan "PT Maju Sejahtera"', completed: false },
      { id: 'obj-3', text: 'Beri format Bold pada waktu atau tempat pertemuan', completed: false },
    ],
    initialData: {
      word: `<h1>Surat Undangan Rapat Koordinasi</h1>
<p>Kepada Yth. Seluruh Kepala Divisi PT Maju Sejahtera di Tempat,</p>
<p>Sehubungan dengan evaluasi kerja kuartal ini, kami mengundang Bapak/Ibu untuk menghadiri rapat yang akan diadakan pada:</p>
<p>Hari/Tanggal: <strong>Senin, 2 November 2026</strong></p>
<p>Waktu: <strong>09.00 - 11.30 WIB</strong></p>
<p>Tempat: <strong>Ruang Rapat Utama Lantai 2</strong></p>
<p>Demikian undangan ini kami sampaikan. Atas perhatian dan kehadirannya kami ucapkan terima kasih.</p>`,
    },
    hints: [
      'Pastikan ada heading <h1> di bagian paling atas dokumen.',
      'Gunakan teks tebal <strong> untuk hari, tanggal, atau ruang rapat.',
      'Pastikan nama PT Maju Sejahtera tertulis dengan benar.',
    ],
    bossHelp: 'Dokumen template sudah hampir sempurna! Pastikan kata "Undangan", "Rapat", dan "PT Maju Sejahtera" lengkap tercantum di teks.',
    referenceSolution: 'Dokumen dengan H1 dan rincian waktu tebal',
    solutionExplanation: 'Standar korespondensi resmi perusahaan menuntut kejelasan visual agar penerima langsung menangkap waktu dan tempat tanpa salah tafsir.',
    commonMistakes: [
      'Menulis judul sebagai teks biasa berukuran kecil tanpa tag Heading.',
      'Lupa menebalkan detail kritis pertemuan.',
    ],
    xpReward: 120,
    coinReward: 60,
    estimatedMinutes: 3,
    skillsTaught: ['Document Typography', 'Heading Hierarchy', 'Emphasis Styling'],
    wordRequirements: {
      scale: 'mikro',
      minWords: 20,
      requiredKeywords: ['Undangan', 'Rapat', 'PT Maju Sejahtera'],
      requireH1: true,
      requireBold: true,
    },
  },

  {
    id: 'word-t2-01',
    module: 'word',
    scale: 'kecil',
    docType: 'Notulen & Matriks Tindak Lanjut',
    tier: 2,
    chapter: 2,
    order: 1,
    title: 'Penyusunan Notulen Rapat & Tabel Tindak Lanjut',
    subtitle: 'Merekap hasil rapat dalam bentuk tabel PIC dan daftar tugas',
    character: 'sari',
    story: 'Bu Sari menginstruksikan pembuatan notulen rapat yang memuat tabel penanggung jawab (PIC) dan tenggat waktu tugas.',
    dialogue: [
      {
        speaker: 'sari',
        text: 'Notulen yang baik harus ada tabel penanggung jawab agar tidak ada tugas yang saling lempar antar divisi.',
        expression: 'stern',
      },
    ],
    conceptBrief: 'Tabel dalam dokumen laporan menyajikan data terstruktur dengan kolom Kegiatan, Penanggung Jawab (PIC), dan Deadline.',
    workedExample: 'Tabel dengan header: Kegiatan | PIC | Batas Waktu',
    objectives: [
      { id: 'obj-1', text: 'Sertakan tabel dengan minimal 3 baris data tindak lanjut', completed: false },
      { id: 'obj-2', text: 'Gunakan Bullet List untuk mencatat poin-poin kesepakatan', completed: false },
      { id: 'obj-3', text: 'Gunakan Sub-Judul (Heading 2) untuk memisahkan agenda', completed: false },
    ],
    initialData: {
      word: `<h1>Notulen Rapat Koordinasi Mingguan</h1>
<h2>Poin Kesepakatan</h2>
<ul>
  <li>Penyelesaian rekonsiliasi kas sebelum tanggal 28.</li>
  <li>Pembaruan sistem inventaris gudang logistik.</li>
</ul>
<h2>Tabel Tindak Lanjut (Action Plan)</h2>
<table>
  <tr><th>Kegiatan</th><th>PIC</th><th>Batas Waktu</th></tr>
  <tr><td>Audit Berkas ATK</td><td>Dimas</td><td>29 Oktober</td></tr>
  <tr><td>Perbaikan Server</td><td>Kak Intan</td><td>30 Oktober</td></tr>
  <tr><td>Penyusunan Slip Gaji</td><td>Pak Reza</td><td>31 Oktober</td></tr>
</table>`,
    },
    hints: [
      'Pastikan dokumen memiliki elemen tabel (<table>) dengan minimal 3 baris isi.',
      'Gunakan bullet list (<ul>) untuk poin kesepakatan rapat.',
      'Beri judul bagian dengan Heading 2 (H2).',
    ],
    bossHelp: 'Periksa kelengkapan tabel dan heading H2. Format sudah terisi rapi, kamu bisa sesuaikan isi sesuai kebutuhan!',
    referenceSolution: 'Notulen lengkap dengan H2, daftar bullet, dan tabel tindak lanjut 3 baris',
    solutionExplanation: 'Tabel notulen adalah dokumen hukum operasional kantor untuk memastikan akuntabilitas pekerjaan.',
    commonMistakes: [
      'Tidak menyertakan tabel, hanya teks narasi panjang.',
      'Lupa mencantumkan penanggung jawab (PIC) tugas.',
    ],
    xpReward: 200,
    coinReward: 80,
    estimatedMinutes: 4,
    skillsTaught: ['Table Creation', 'Action Plan Matrix', 'Executive Minutes'],
    wordRequirements: {
      scale: 'kecil',
      minWords: 25,
      requireH2: true,
      requireTable: true,
      minTableRows: 3,
      requireList: true,
    },
  },

  {
    id: 'word-t3-01',
    module: 'word',
    scale: 'akademik',
    docType: 'Makalah / Laporan PKL',
    tier: 3,
    chapter: 3,
    order: 1,
    title: 'Format Akademik Indonesia (Margin 4-3-3-3 & Sitasi)',
    subtitle: 'Menyusun Laporan PKL & Makalah Penelitian Ilmiah Bab 1',
    character: 'maya',
    story: 'Banyak mahasiswa dan siswa SMK magang kesulitan menyusun Laporan PKL atau Bab 1 Skripsi sesuai pedoman penulisan ilmiah Indonesia.',
    dialogue: [
      {
        speaker: 'maya',
        text: 'Standar penulisan ilmiah di Indonesia wajib menggunakan kertas A4, margin 4 cm kiri, 3 cm atas, 3 cm kanan, dan 3 cm bawah, serta spasi 1.5. Coba terapkan pada draf Bab 1 ini!',
        expression: 'proud',
      },
    ],
    conceptBrief: 'Pedoman penulisan ilmiah Indonesia mengatur margin kiri 4 cm untuk jilid, margin atas 3 cm, kanan 3 cm, dan bawah 3 cm dengan font formal Times New Roman 12 pt spasi 1.5.',
    workedExample: 'Heading 1: BAB I PENDAHULUAN | Heading 2: 1.1 Latar Belakang Masalah | Sitasi: [1]',
    objectives: [
      { id: 'obj-1', text: 'Gunakan Heading 1 untuk "BAB I PENDAHULUAN"', completed: false },
      { id: 'obj-2', text: 'Gunakan Heading 2 untuk "1.1 Latar Belakang Masalah" dan "1.2 Rumusan Masalah"', completed: false },
      { id: 'obj-3', text: 'Sertakan nomor sitasi atau rujukan pustaka [1]', completed: false },
    ],
    initialData: {
      word: `<h1>BAB I PENDAHULUAN</h1>
<h2>1.1 Latar Belakang Masalah</h2>
<p>Perkembangan teknologi informasi mendorong transformasi digital pada proses bisnis modern di PT Maju Sejahtera <sup>[1]</sup>. Efisiensi operasional sangat bergantung pada pemanfaatan spreadsheet dan sistem basis data yang terintegrasi.</p>
<h2>1.2 Rumusan Masalah</h2>
<ul>
  <li>Bagaimana efektivitas automasi formula dalam mengurangi kesalahan hitung kasir?</li>
  <li>Bagaimana peningkatan kecepatan serah terima laporan mingguan pasca digitalisasi?</li>
</ul>`,
    },
    hints: [
      'Pastikan terdapat judul bab utama menggunakan <h1>.',
      'Sertakan sub-bab 1.1 dan 1.2 menggunakan <h2>.',
      'Tambahkan penanda sitasi seperti <sup>[1]</sup> atau [1].',
    ],
    bossHelp: 'Gunakan tombol H1 untuk BAB I PENDAHULUAN, H2 untuk sub-bab, dan sisipkan tombol Sitasi [1] untuk catatan pustaka.',
    referenceSolution: 'Format Bab 1 dengan H1, H2, dan sitasi pustaka',
    solutionExplanation: 'Standar penulisan akademik 4-3-3-3 cm dan spasi 1.5 adalah format baku kelulusan skripsi dan laporan PKL di perguruan tinggi Indonesia.',
    commonMistakes: [
      'Menulis judul bab tanpa tag Heading 1.',
      'Lupa mencantumkan rumusan masalah.',
    ],
    xpReward: 300,
    coinReward: 120,
    estimatedMinutes: 5,
    skillsTaught: ['Academic Formatting', 'Margin 4-3-3-3', 'Citation Styles', 'Thesis Structure'],
    wordRequirements: {
      scale: 'akademik',
      academicPreset: true,
      minWords: 40,
      requireH1: true,
      requireH2: true,
      requireFootnote: true,
      requiredKeywords: ['BAB I', 'Latar Belakang', 'Rumusan Masalah'],
    },
  },
];
