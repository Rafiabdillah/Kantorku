import { CaseFile } from '../types';

export const CASE_FILES: CaseFile[] = [
  {
    id: 'case-01-sayur',
    title: 'Rekap Penjualan Sayur Segar UMKM',
    industry: 'Toko Sayur Online UMKM',
    tier: 3,
    module: 'excel',
    channel: 'whatsapp',
    deadlineHours: 4,
    clientName: 'Pak Joko (Toko Sayur Segar)',
    character: 'sari',
    summary: 'Data penjualan sayur harian berantakan: ada sel kosong, harga tercampur spasi, dan butuh total omzet bersih.',
    emails: [
      {
        from: 'joko.sayur@mitra.com',
        subject: 'Rekap Penjualan Sayur Segar Minggu 1',
        timestamp: '08:15 WIB',
        body: 'Halo tim PT Maju Sejahtera, ini catatan penjualan seminggu kemarin dari kasir kami. Masih berantakan dan ada harga yang salah ketik. Tolong hitung total omzet bersih dan barang yang paling laris ya.',
        attachments: ['penjualan_minggu_1.xlsx'],
      },
    ],
    chats: [
      { sender: 'Bu Sari', role: 'Direktur Operasional', time: '08:20', message: 'Tolong prioritaskan ini ya. UMKM Pak Joko adalah mitra binaan strategis kita.' },
      { sender: 'Pak Reza', role: 'Finance', time: '08:21', message: 'Hati-hati, pisahkan retur pembeli agar laporan laba rugi tidak terdistorsi.' },
      { sender: 'Dimas', role: 'Rekan Tim', time: '08:22', message: 'Kemarin aku intip ada angka yang tersimpan sebagai teks di kolom B, cek formatnya dulu bro.' },
    ],
    voiceNotes: [
      {
        speaker: 'Pak Joko (Owner)',
        duration: '0:42',
        transcript: 'Halo mas/mbak, maaf ya kemarin anak kasir baru buru-buru, jadi beberapa catatan retur belum sempat dikurangkan. Tolong bantu dibereskan ya.',
      },
    ],
    clarifyingQuestions: [
      {
        id: 'q1',
        question: 'Apakah komoditas yang batal dibeli (status: Retur) harus dihitung dalam total omzet bersih?',
        options: [
          { id: 'opt-a', text: 'Keluarkan transaksi Retur dari total omzet penjualan bersih', isOptimal: true, bossResponse: 'Tepat sekali! Omzet bersih tidak boleh mencakup barang retur.' },
          { id: 'opt-b', text: 'Hitung semuanya saja tanpa melihat status retur', isOptimal: false, bossResponse: 'Kurang tepat, itu akan membuat omzet terlihat semu/fiktif.' },
        ],
      },
    ],
    scopeChange: {
      triggerAfterMinutes: 2,
      sender: 'Bu Sari',
      message: 'Eh, Pak Joko barusan telepon lagi: tolong tambahkan juga persentase kontribusi per komoditas ya!',
      newObjective: 'Hitung persentase omzet masing-masing komoditas terhadap total omzet di kolom C.',
    },
    initialData: {
      excel: {
        A1: { raw: 'Komoditas', isHeader: true },
        B1: { raw: 'Omzet Penjualan', isHeader: true },
        C1: { raw: 'Porsi Omzet', isHeader: true },
        A2: { raw: 'Bayam Organik' },
        B2: { raw: '450000', format: 'rupiah' },
        C2: { raw: '', format: 'percent' },
        A3: { raw: 'Wortel Brastagi' },
        B3: { raw: '750000', format: 'rupiah' },
        C3: { raw: '', format: 'percent' },
        A4: { raw: 'Tomat Ceri' },
        B4: { raw: '300000', format: 'rupiah' },
        C4: { raw: '', format: 'percent' },
        A5: { raw: 'TOTAL OMZET', isHeader: true },
        B5: { raw: '=SUM(B2:B4)', format: 'rupiah' },
        C5: { raw: '=SUM(C2:C4)', format: 'percent' },
      },
    },
    referenceSolutions: ['C2: =B2/$B$5, C3: =B3/$B$5, C4: =B4/$B$5'],
    reputationReward: 15,
    xpReward: 350,
    coinsReward: 120,
    mentorDebrief: {
      keyTakeaway: 'Penggunaan referensi absolut $B$5 mencegah pergeseran rumus pembagi saat ditarik ke baris berikutnya.',
      pitfallAvoided: 'Menghindari pembagian dengan nol atau sel kosong akibat rumus relatif yang tidak dikunci.',
      industryContext: 'Di sektor ritel & UMKM, kalkulasi persentase porsi kategori (product mix) krusial untuk penataan etalase toko.',
    },
  },

  {
    id: 'case-02-klinik',
    title: 'Audit Pasien BPJS & Rawat Jalan Klinik',
    industry: 'Klinik Kesehatan Pratama',
    tier: 4,
    module: 'excel',
    channel: 'email',
    deadlineHours: 5,
    clientName: 'dr. Ratna (Klinik Sehat Sentosa)',
    character: 'reza',
    summary: 'Klinik butuh pemisahan klaim pasien BPJS vs Umum secara otomatis dengan rumus IF dan rekap tarif.',
    emails: [
      {
        from: 'ratna@kliniksentosa.id',
        subject: 'Rekonsiliasi Klaim BPJS Bulan Oktober',
        timestamp: '09:00 WIB',
        body: 'Selamat pagi, data kunjungan pasien kami belum terpisah antara BPJS (tarif subsidi Rp 50.000) dan Pasien Umum (Rp 120.000). Mohon bantuannya agar klaim ke kantor BPJS tidak ditolak.',
      },
    ],
    chats: [
      { sender: 'Pak Reza', role: 'Finance Lead', time: '09:05', message: 'Gunakan IF bertingkat atau lookup tarif. Jangan sampai ada salah klaim satu rupiah pun!' },
      { sender: 'Maya', role: 'HR & Kepatuhan', time: '09:08', message: 'Pastikan data nama pasien anonim dan memenuhi kerahasiaan medis ya.' },
    ],
    clarifyingQuestions: [
      {
        id: 'q1',
        question: 'Apakah pasien BPJS yang mengambil obat khusus dikenakan biaya tambahan di luar subsidi?',
        options: [
          { id: 'opt-a', text: 'Sesuai regulasi faskes primer, obat khusus dicatat pada kolom iuran tambahan', isOptimal: true, bossResponse: 'Bagus! Regulasi faskes memang mewajibkan pemisahan iuran tambahan.' },
          { id: 'opt-b', text: 'Gabungkan saja ke dalam tarif pokok BPJS', isOptimal: false, bossResponse: 'Jangan! Itu melanggar aturan klaim BPJS.' },
        ],
      },
    ],
    initialData: {
      excel: {
        A1: { raw: 'Nama Pasien', isHeader: true },
        B1: { raw: 'Jenis Pasien', isHeader: true },
        C1: { raw: 'Biaya Klaim', isHeader: true },
        A2: { raw: 'Slamet Riyadi' },
        B2: { raw: 'BPJS' },
        C2: { raw: '', format: 'rupiah' },
        A3: { raw: 'Dewi Lestari' },
        B3: { raw: 'Umum' },
        C3: { raw: '', format: 'rupiah' },
        A4: { raw: 'Rudi Hartono' },
        B4: { raw: 'BPJS' },
        C4: { raw: '', format: 'rupiah' },
        A5: { raw: 'TOTAL KLAIM', isHeader: true },
        B5: { raw: '' },
        C5: { raw: '=SUM(C2:C4)', format: 'rupiah' },
      },
    },
    referenceSolutions: ['C2: =IF(B2="BPJS", 50000, 120000)'],
    reputationReward: 20,
    xpReward: 400,
    coinsReward: 150,
    mentorDebrief: {
      keyTakeaway: 'Kondisional IF memudahkan pengelompokan tarif otomatis tanpa perlu entri berulang oleh staf loket.',
      pitfallAvoided: 'Koreksi tarif ganda saat pasien berganti kategori jaminan kesehatan.',
      industryContext: 'Fasilitas kesehatan primer menuntut audit kepatuhan klaim yang ketat dari BPJS Kesehatan.',
    },
  },

  {
    id: 'case-03-web-umkm',
    title: 'Desain Landing Page Toko Kue Ibu Siti',
    industry: 'F&B Kuliner & UMKM',
    tier: 3,
    module: 'web',
    channel: 'whatsapp',
    deadlineHours: 6,
    clientName: 'Ibu Siti (Dapur Manis)',
    character: 'nadia',
    summary: 'Buat halaman profil toko kue responsif yang memuat header, kartu menu terlaris dengan flexbox, dan tombol order.',
    emails: [],
    chats: [
      { sender: 'Nadia', role: 'Marketing', time: '10:00', message: 'Ibu Siti ingin websitenya cantik dan gampang dibuka di HP pelanggan pas mau pesan kue ulang tahun.' },
      { sender: 'Kak Intan', role: 'IT Lead', time: '10:05', message: 'Gunakan semantic HTML dan CSS Flexbox responsif ya, jangan pakai tabel kuno untuk layout!' },
    ],
    voiceNotes: [
      {
        speaker: 'Ibu Siti',
        duration: '0:35',
        transcript: 'Mbak Nadia, tolong ya foto bolu kukus dan lapis legitnya ditata berdampingan rapi, tombol pesannya dibikin warna hijau biar mirip WA.',
      },
    ],
    clarifyingQuestions: [
      {
        id: 'q1',
        question: 'Apakah nomor WhatsApp pemesanan langsung ditautkan ke tombol?',
        options: [
          { id: 'opt-a', text: 'Tautkan tombol CTA ke link api.whatsapp.com dengan pesan pra-isi', isOptimal: true, bossResponse: 'Ide luar biasa! Konversi penjualan UMKM akan melonjak tinggi.' },
          { id: 'opt-b', text: 'Tampilkan teks nomor telepon polos tanpa link aktif', isOptimal: false, bossResponse: 'Pengguna HP akan kesulitan jika harus copy-paste nomor manual.' },
        ],
      },
    ],
    initialData: {
      html: `<header>
  <h1>Dapur Manis Ibu Siti</h1>
  <p>Kue Tradisional & Bolu Lembut Khas Nusantara</p>
</header>
<main>
  <div class="menu-container">
    <div class="menu-item">
      <h3>Bolu Gulung Pandan</h3>
      <p>Rp 65.000</p>
    </div>
    <div class="menu-item">
      <h3>Lapis Legit Wisman</h3>
      <p>Rp 150.000</p>
    </div>
  </div>
  <button class="btn-order">Pesan via WhatsApp</button>
</main>`,
      css: `header { text-align: center; padding: 20px; background: #fff7ed; }
h1 { color: #9a3412; margin: 0; }
.menu-container { display: flex; gap: 16px; padding: 20px; }
.menu-item { flex: 1; border: 1px solid #fed7aa; padding: 16px; border-radius: 12px; background: white; text-align: center; }
.btn-order { display: block; width: 100%; max-width: 240px; margin: 20px auto; padding: 12px; background: #16a34a; color: white; border: none; border-radius: 8px; font-weight: bold; cursor: pointer; }`,
    },
    referenceSolutions: ['Semantic HTML dengan header, main, dan .menu-container display: flex'],
    reputationReward: 25,
    xpReward: 450,
    coinsReward: 160,
    mentorDebrief: {
      keyTakeaway: 'Penggunaan semantik HTML (<header>, <main>) mempermudah bot Google mengindeks profil toko UMKM.',
      pitfallAvoided: 'Layout rusak pada layar kecil karena penggunaan Flexbox fluid.',
      industryContext: 'UMKM modern bertransformasi dari sekadar chat manual ke landing page terintegrasi untuk meningkatkan kepercayaan.',
    },
  },
];
